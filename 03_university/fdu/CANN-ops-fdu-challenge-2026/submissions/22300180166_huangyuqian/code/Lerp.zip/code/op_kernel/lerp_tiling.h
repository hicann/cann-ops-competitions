#ifndef LERP_TILING_H
#define LERP_TILING_H

// ★ 核心修复：消除 CANN 工具链因输入名为 "end" 自动生成的宏，防止与系统枚举冲突！
#ifdef FORMAT_END
#undef FORMAT_END
#endif

#include "register/tilingdata_base.h"

namespace optiling {

BEGIN_TILING_DATA_DEF(LerpTilingData)
    TILING_DATA_FIELD_DEF(uint32_t, smallCoreDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, bigCoreDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, finalBigTileNum);
    TILING_DATA_FIELD_DEF(uint32_t, finalSmallTileNum);
    TILING_DATA_FIELD_DEF(uint32_t, tileDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, smallTailDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, bigTailDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, tailBlockNum);
    TILING_DATA_FIELD_DEF(float, weight); 
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(Lerp, LerpTilingData)

} // namespace optiling

#endif // LERP_TILING_H