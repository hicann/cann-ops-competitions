#include "lerp_tiling.h"
#include "tiling_key_lerp.h"
#include "kernel_operator.h"

constexpr int32_t BUFFER_NUM = 2; // 双缓冲

template<typename TYPE_X> class KernelLerp {
public:
    __aicore__ inline KernelLerp() {}
    
    __aicore__ inline void Init(GM_ADDR start, GM_ADDR end, GM_ADDR y, uint32_t smallCoreDataNum,
                                uint32_t bigCoreDataNum, uint32_t finalBigTileNum, 
                                uint32_t finalSmallTileNum, uint32_t tileDataNum, 
                                uint32_t smallTailDataNum, uint32_t bigTailDataNum, 
                                uint32_t tailBlockNum, float weight) 
    {
        uint32_t coreNum = AscendC::GetBlockIdx();
        uint32_t globalBufferIndex = bigCoreDataNum * AscendC::GetBlockIdx();
        this->tileDataNum = tileDataNum;
        
        // 核心判决：大小核差异化数据分配逻辑
        if (coreNum < tailBlockNum) { 
          this->coreDataNum = bigCoreDataNum;
          this->tileNum = finalBigTileNum;
          this->tailDataNum = bigTailDataNum;
        }
        else { 
          this->coreDataNum = smallCoreDataNum;
          this->tileNum = finalSmallTileNum;
          this->tailDataNum = smallTailDataNum;
          globalBufferIndex -= (bigCoreDataNum - smallCoreDataNum) * (AscendC::GetBlockIdx() - tailBlockNum);
        }
        
        // 绑定 Global 内存
        startGm.SetGlobalBuffer((__gm__ TYPE_X*)start + globalBufferIndex, this->coreDataNum);
        endGm.SetGlobalBuffer((__gm__ TYPE_X*)end + globalBufferIndex, this->coreDataNum);
        yGm.SetGlobalBuffer((__gm__ TYPE_X*)y + globalBufferIndex, this->coreDataNum);
        
        // 初始化 3 个队列的 UB 空间
        pipe.InitBuffer(inQueueStart, BUFFER_NUM, this->tileDataNum * sizeof(TYPE_X));
        pipe.InitBuffer(inQueueEnd, BUFFER_NUM, this->tileDataNum * sizeof(TYPE_X));
        pipe.InitBuffer(outQueueY, BUFFER_NUM, this->tileDataNum * sizeof(TYPE_X));
        
        // 保存并强转标量属性
        this->weight = static_cast<TYPE_X>(weight);
    }
    
    __aicore__ inline void Process()
    {
        int32_t loopCount = this->tileNum;
        this->processDataNum = this->tileDataNum;
        
        for (int32_t i = 0; i < loopCount; i++) {
            if (i == this->tileNum - 1) {
              this->processDataNum = this->tailDataNum;
            }
            CopyIn(i);
            Compute(i);
            CopyOut(i);
        }
    }

private:
    __aicore__ inline void CopyIn(int32_t progress)
    {
        // 搬运 start
        AscendC::LocalTensor<TYPE_X> startLocal = inQueueStart.AllocTensor<TYPE_X>();
        AscendC::DataCopy(startLocal, startGm[progress * this->tileDataNum], this->processDataNum);
        inQueueStart.EnQue(startLocal);
        
        // 搬运 end
        AscendC::LocalTensor<TYPE_X> endLocal = inQueueEnd.AllocTensor<TYPE_X>();
        AscendC::DataCopy(endLocal, endGm[progress * this->tileDataNum], this->processDataNum);
        inQueueEnd.EnQue(endLocal);
    }
    
    __aicore__ inline void Compute(int32_t progress)
    {
        AscendC::LocalTensor<TYPE_X> startLocal = inQueueStart.DeQue<TYPE_X>();
        AscendC::LocalTensor<TYPE_X> endLocal = inQueueEnd.DeQue<TYPE_X>();
        AscendC::LocalTensor<TYPE_X> yLocal = outQueueY.AllocTensor<TYPE_X>();
        
        // ★ 核心插值计算：y = start + weight * (end - start)
        // 巧妙利用 endLocal 作为中间变量做 In-place 运算，节省 UB
        
        // 1. endLocal = end - start
        AscendC::Sub(endLocal, endLocal, startLocal, this->processDataNum);
        
        // 2. endLocal = weight * (end - start)
        AscendC::Muls(endLocal, endLocal, this->weight, this->processDataNum);
        
        // 3. yLocal = start + weight * (end - start)
        AscendC::Add(yLocal, startLocal, endLocal, this->processDataNum);
        
        // 压入输出队列，释放输入内存
        outQueueY.EnQue<TYPE_X>(yLocal);
        inQueueStart.FreeTensor(startLocal);
        inQueueEnd.FreeTensor(endLocal);
    }
    
    __aicore__ inline void CopyOut(int32_t progress)
    {
        AscendC::LocalTensor<TYPE_X> yLocal = outQueueY.DeQue<TYPE_X>();  
        AscendC::DataCopy(yGm[progress * this->tileDataNum], yLocal, this->processDataNum);
        outQueueY.FreeTensor(yLocal);
    }

private:
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, BUFFER_NUM> inQueueStart;
    AscendC::TQue<AscendC::QuePosition::VECIN, BUFFER_NUM> inQueueEnd;
    AscendC::TQue<AscendC::QuePosition::VECOUT, BUFFER_NUM> outQueueY;
    
    AscendC::GlobalTensor<TYPE_X> startGm;
    AscendC::GlobalTensor<TYPE_X> endGm;
    AscendC::GlobalTensor<TYPE_X> yGm;
    
    uint32_t coreDataNum;
    uint32_t tileNum;
    uint32_t tileDataNum;
    uint32_t tailDataNum;
    uint32_t processDataNum;
    TYPE_X weight; // 插值权重标量
};

// 避免宏冲突陷阱：使用脱离宏定义的泛型变量名 T，且不用 extern "C"
template <typename T>
__global__ __aicore__ void lerp(GM_ADDR start, GM_ADDR end, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling)
{
    GET_TILING_DATA(tiling_data, tiling);
    
    KernelLerp<T> op;
    op.Init(start, end, y, 
            tiling_data.smallCoreDataNum, tiling_data.bigCoreDataNum, 
            tiling_data.finalBigTileNum, tiling_data.finalSmallTileNum, 
            tiling_data.tileDataNum, tiling_data.smallTailDataNum, 
            tiling_data.bigTailDataNum, tiling_data.tailBlockNum, 
            tiling_data.weight);
            
    op.Process();
}