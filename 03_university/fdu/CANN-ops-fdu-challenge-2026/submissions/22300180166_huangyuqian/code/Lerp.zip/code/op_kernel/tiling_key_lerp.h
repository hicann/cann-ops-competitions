#pragma once
#include "ascendc/host_api/tiling/template_argument.h"

// 声明模板参数 DTYPE_X，支持 FP16, FP32
ASCENDC_TPL_ARGS_DECL(Lerp,
    ASCENDC_TPL_DATATYPE_DECL(DTYPE_X, C_DT_FLOAT16, C_DT_FLOAT)
);

// 注册具体的类型实例分支
ASCENDC_TPL_SEL(
    ASCENDC_TPL_ARGS_SEL(
        ASCENDC_TPL_DATATYPE_SEL(DTYPE_X, C_DT_FLOAT16)
    ),
    ASCENDC_TPL_ARGS_SEL(
        ASCENDC_TPL_DATATYPE_SEL(DTYPE_X, C_DT_FLOAT)
    )
);