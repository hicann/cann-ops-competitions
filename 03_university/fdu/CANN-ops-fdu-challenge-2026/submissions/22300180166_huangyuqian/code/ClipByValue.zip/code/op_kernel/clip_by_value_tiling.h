#ifndef CLIP_BY_VALUE_TILING_H
#define CLIP_BY_VALUE_TILING_H

#include "register/tilingdata_base.h"

namespace optiling {

BEGIN_TILING_DATA_DEF(ClipByValueTilingData)
    TILING_DATA_FIELD_DEF(uint32_t, smallCoreDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, bigCoreDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, finalBigTileNum);
    TILING_DATA_FIELD_DEF(uint32_t, finalSmallTileNum);
    TILING_DATA_FIELD_DEF(uint32_t, tileDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, smallTailDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, bigTailDataNum);
    TILING_DATA_FIELD_DEF(uint32_t, tailBlockNum);
    TILING_DATA_FIELD_DEF(float, min);
    TILING_DATA_FIELD_DEF(float, max);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(ClipByValue, ClipByValueTilingData)

} // namespace optiling

#endif // CLIP_BY_VALUE_TILING_H